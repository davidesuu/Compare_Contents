#ifndef CSV_H
#define CSV_H
#include "name.h"

void init_csv();

void write_csv_cont(char *file1, char *file2, double jaccard);

void write_csv_name(char *file1, char *file2);

#endif
